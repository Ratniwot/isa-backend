package com.online_cinema_management.services;

import com.online_cinema_management.models.Director;
import com.online_cinema_management.models.Movie;
import com.online_cinema_management.models.Genre;
import com.online_cinema_management.repositories.DirectorRepository;
import com.online_cinema_management.repositories.MovieRepository;
import com.online_cinema_management.repositories.GenreRepository;
import com.online_cinema_management.repositories.ReviewRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class MovieService {

    @Autowired
    private MovieRepository movieRepository;

    @Autowired
    private DirectorRepository directorRepository;

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private GenreRepository genreRepository;


    public List<Movie> getAllMovies() {
        return movieRepository.findAll();
    }

    public Optional<Movie> getMovieById(Long id) {
        return movieRepository.findById(id);
    }

    @Transactional
    public Movie saveMovie(Movie movie) {

        Set<Director> managedDirectors = new HashSet<>();
        for (Director director : movie.getDirectors()) {
            Director managedDirector = directorRepository.findById(director.getId()).orElseThrow(() -> new RuntimeException("Režiser nije pronadjen"));
            managedDirectors.add(managedDirector);
        }
        movie.setDirectors(managedDirectors);


        return movieRepository.save(movie);
    }

    @Transactional
    public Movie updateMovie(Long id, Movie movie) {

        Movie existingMovie = movieRepository.findById(id).orElseThrow(() -> new RuntimeException("Film nije pronadjen"));


        Genre genre = genreRepository.findById(movie.getGenre().getId())
                .orElseThrow(() -> new RuntimeException("Žanr nije pronadjen"));
        existingMovie.setGenre(genre);


        Set<Director> managedDirectors = new HashSet<>();
        for (Director director : movie.getDirectors()) {
            Director managedDirector = directorRepository.findById(director.getId())
                    .orElseThrow(() -> new RuntimeException("Režiser nije pronadjen"));
            managedDirectors.add(managedDirector);
        }
        existingMovie.setDirectors(managedDirectors);


        existingMovie.setTitle(movie.getTitle());
        existingMovie.setIsbn(movie.getIsbn());


        return movieRepository.save(existingMovie);
    }


    @Transactional
    public void deleteMovie(Long id) {
        Movie movie = movieRepository.findById(id).orElseThrow(() -> new RuntimeException("Film nije pronadjena"));


        Set<Director> directors = new HashSet<>(movie.getDirectors());
        for (Director director : directors) {
            director.getMovies().remove(movie);
        }
        movie.setDirectors(null);


        reviewRepository.deleteAll(movie.getReviews());


        movieRepository.delete(movie);
    }

}
