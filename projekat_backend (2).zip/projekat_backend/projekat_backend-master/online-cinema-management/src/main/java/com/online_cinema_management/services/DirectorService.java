package com.online_cinema_management.services;

import com.online_cinema_management.models.Director;
import com.online_cinema_management.repositories.DirectorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DirectorService {

    @Autowired
    private DirectorRepository DirectorRepository;

    public List<Director> getAllDirectors() {
        return DirectorRepository.findAll();
    }

    public Optional<Director> getDirectorById(Long id) {
        return DirectorRepository.findById(id);
    }

    public Director saveDirector(Director Director) {
        return DirectorRepository.save(Director);
    }

    public void deleteDirector(Long id) {
        DirectorRepository.deleteById(id);
    }
}
